package com.example.demo.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Menu {
	@Id
	String name;
	Double price;
	String active;
	@DateTimeFormat(pattern = "yyy-MM-dd")
	Date dateOfLaunch;
	String category;
	String freeDelivery;
	
	public Menu() {}

	public Menu(String name, Double price, String active, Date dateOfLaunch, String category, String freeDelivery) {
		super();
		this.name = name;
		this.price = price;
		this.active = active;
		this.dateOfLaunch = dateOfLaunch;
		this.category = category;
		this.freeDelivery = freeDelivery;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getprice() {
		return price;
	}

	public void setprice(Double price) {
		this.price = price;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public Date getDateOfLaunch() {
		return dateOfLaunch;
	}
	public String getDateOfLaunch1()
	{
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(dateOfLaunch);
	}
	
	public String getDateOfLaunch2()
	{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(dateOfLaunch);
	}

	public void setDateOfLaunch(Date dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFreeDelivery() {
		return freeDelivery;
	}

	public void setFreeDelivery(String freeDelivery) {
		this.freeDelivery = freeDelivery;
	}

	@Override
	public String toString() {
		return "Menu [name=" + name + ", price=" + price + ", active=" + active + ", dateOfLaunch=" + dateOfLaunch
				+ ", category=" + category + ", freeDelivery=" + freeDelivery + "]";
	}
	
}
