package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LomborkDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(LomborkDemo2Application.class, args);
	}

}
