package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.Menu;
import com.example.demo.service.MenuService;

@Controller
public class MyController {
	@Autowired
	private MenuService ms;

	@GetMapping("/home")
	public String home()
	{
		return "index";
	}
	
	@GetMapping("/menu")
//	@ResponseBody
	public ModelAndView menuHome()
	{
		List<Menu> menuItems = ms.read();
		ModelAndView mv=new ModelAndView();
		mv.setViewName("menu");
		mv.addObject("menuItems", menuItems);
		return mv;
	}
	
	@PostMapping("/menu")
	public ModelAndView addMenu(Menu menu)
	{
//		System.out.println(menu);
		//check if free delivery null
		if(menu.getFreeDelivery()==null)
			menu.setFreeDelivery("No");
		System.out.println(ms.create(menu));
		return menuHome();
	}
	
	@PostMapping("/menu/update")
	public ModelAndView updateMenu(Menu menu)
	{
//		System.out.println(menu);
		//check if free delivery null
		if(menu.getFreeDelivery()==null)
			menu.setFreeDelivery("No");
		System.out.println(ms.update(menu));
		return menuHome();
	}
	
	@GetMapping("/menu/{name}")
	public ModelAndView findMenuByName(@PathVariable("name")String name)
	{
		Menu menu = ms.read(name);
		System.out.println("Found menu: "+menu);
		ModelAndView mv=new ModelAndView("edit");
		mv.addObject("menu", menu);
		return mv;
	}
}
