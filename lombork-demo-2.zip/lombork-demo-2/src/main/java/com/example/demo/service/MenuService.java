package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Menu;
import com.example.demo.repository.MenuRepository;

@Component
public class MenuService {

	@Autowired
	private MenuRepository menuRepository;

	public MenuRepository getMenuRepository() {
		return menuRepository;
	}

	public void setMenuRepository(MenuRepository menuRepository) {
		this.menuRepository = menuRepository;
	}
	
	public Menu create(Menu menu) {
		return menuRepository.save(menu);
	}
	public List<Menu> read() {
		return menuRepository.findAll();
	}
	public Menu read(String name) {
		return menuRepository.findById(name).get();
	}
	public Menu update(Menu menu) {
		return menuRepository.save(menu);
	}
	public void delete(String name) {
		menuRepository.delete(read(name));
	}
	
}
