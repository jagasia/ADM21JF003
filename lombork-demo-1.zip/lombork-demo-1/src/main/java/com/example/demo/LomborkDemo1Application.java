package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class LomborkDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(LomborkDemo1Application.class, args);
		Employee employee=new Employee();
		employee.setId(12L);
		employee.setFirstName("Ram");
		employee.setLastName("Kumar");
		log.info("This is an info by lombok");
		log.warn("This is a warning");
		System.out.println(employee);
	}

}
