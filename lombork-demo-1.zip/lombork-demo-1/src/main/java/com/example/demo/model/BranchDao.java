package com.example.demo.model;

import java.util.List;

import com.example.demo.entity.Branch;

public interface BranchDao {

	void create(Branch branch);

	List<Branch> read();

	Branch read(String bid);

	void update(Branch branch);

	void delete(String bid);

}