package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Branch;
import com.example.demo.model.BranchDao;
import com.example.demo.model.BranchDaoImpl;

@RestController
public class BranchController {
	@Autowired
	private BranchDao bdao;
	
	@GetMapping("/")
	public String home()
	{
		return "Welcome to home";
	}
	
	@GetMapping("/branch")
	public List<Branch> getAllBranches()
	{
		return bdao.read();
	}
	
	@GetMapping("/branch/{bid}")
	public Branch getAllBranches(@PathVariable("bid") String bid)
	{
		return bdao.read(bid);
	}
	
	@PostMapping("/branch")
	public void create(@RequestBody Branch branch)
	{
		 bdao.create(branch);
	}
	
	@PutMapping("/branch")
	public void update(@RequestBody Branch branch)
	{
		bdao.update(branch);
	}
	
	@DeleteMapping("/branch/{bid}")
	public void delete(@PathVariable("bid") String bid)
	{
		bdao.delete(bid);
	}
	
}
