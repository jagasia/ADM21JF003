package com.example.demo.model;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Branch;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class BranchDaoImpl implements BranchDao {
	
	@Override
	public void create(Branch branch) {
		Session session = getSession();
		Transaction tran = session.beginTransaction();
		session.save(branch);
		log.info("A branch is being added now");
		tran.commit();
		session.close();
	}
	@Override
	public List<Branch> read() {
		Session session = getSession();
		Criteria criteria=session.createCriteria(Branch.class);
		List<Branch> branches = criteria.list();
		log.info("There are "+branches.size()+" Branches.");
		session.close();
		return branches;
	}
	@Override
	public Branch read(String bid) {
		Session session = getSession();
		 Criteria criteria = session.createCriteria(Branch.class);
		 criteria.add(Restrictions.eq("bid", bid));
		 List<Branch> result = criteria.list();
		 if(result.size()==0)
		 {
			 log.warn("There is no branch found for the id "+bid);
			 session.close();
			 return null;
		 }		 
		session.close();
		return result.get(0);
	}
	@Override
	public void update(Branch branch) {
		Session session = getSession();
		Branch b1 = session.get(Branch.class, branch.getBid());
		if(b1==null)
		{
			 log.warn("There is no branch found for the id "+branch.getBid());
			 session.close();
			 return;
		}
		b1.setBname(branch.getBname());
		b1.setBcity(branch.getBcity());
		Transaction tran = session.beginTransaction();
		session.persist(b1);		
		tran.commit();
		session.close();
		log.info("The branch with bid "+branch.getBid()+" is being updated now");
	}
	@Override
	public void delete(String bid) {
		Session session = getSession();
		Branch branch=read(bid);
		if(branch==null)
		{
			 log.warn("There is no branch found for the id "+bid);
			 session.close();
			 return;
		}
		Transaction tran = session.beginTransaction();
		session.delete(branch);
		tran.commit();
		session.close();
		log.info("A branch with bid "+ bid +" is being deleted now");
	}
	
	
	
	private Session getSession()
	{
		 Configuration config=new Configuration();
	        config.configure("hibernate.cfg.xml");
	        config.addAnnotatedClass(Branch.class);
	        Session session = config.buildSessionFactory()
	        .openSession();
	        return session;
	}

}
