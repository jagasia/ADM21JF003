package com.example.demo;

import lombok.Data;

@Data
public class Employee {
	private Long id;
	private String firstName, lastName;
}
