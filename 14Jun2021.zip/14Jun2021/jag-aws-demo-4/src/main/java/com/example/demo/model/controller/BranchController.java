package com.example.demo.model.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Branch;
import com.example.demo.repository.BranchRepository;

@RestController
@CrossOrigin(origins = {"*","http://localhost:4200"})
public class BranchController {

	@Autowired
	private BranchRepository br;
	
	
	
	@PostMapping("/branch")
	public Branch create(@RequestBody Branch branch) {
		return br.save(branch);
	}
	
	@GetMapping("/branch")
	public List<Branch> read() {
//		List<Branch> branchList=new ArrayList<>();
//		branchList.add(new Branch("B00001","Asaf Ali road", "New Delhi"));
//		branchList.add(new Branch("B00002","Old Delhi main road", "New Delhi"));
//		branchList.add(new Branch("B00003","Delhi contt", "Chennai"));
//		branchList.add(new Branch("B00004","Jasola", "Kolkata"));
//		branchList.add(new Branch("B00005","Ann marry", "Mumbai"));
		return br.findAll();
	}
	
	@GetMapping("/branch/{bid}")
	public Branch read(@PathVariable("bid") String bid) {
//		return new Branch("B00001","Asaf Ali road", "New Delhi");
		return br.findById(bid).get();
	}
	
	@PutMapping("/branch")
	public Branch update(@RequestBody Branch branch) {
		return br.save(branch);
	}
	
	@DeleteMapping("/branch/{bid}")
	public int delete(@PathVariable("bid") String bid) {
		br.delete(read(bid));
		return 1;
	}
	
}
