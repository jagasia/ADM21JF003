package com.cts.jf003.truyum_demo_1.model;

public class MenuItem {
	private int menuId;
	private String name;
	private Double price;
	public MenuItem() {}
	public MenuItem(int menuId, String name, Double price) {
		super();
		this.menuId = menuId;
		this.name = name;
		this.price = price;
	}
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
}
