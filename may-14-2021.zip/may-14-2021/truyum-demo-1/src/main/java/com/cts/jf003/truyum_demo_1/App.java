package com.cts.jf003.truyum_demo_1;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.jf003.truyum_demo_1.model.MenuItem;
import com.cts.jf003.truyum_demo_1.model.MenuItemCollection;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
        MenuItemCollection mic= (MenuItemCollection) ctx.getBean("menuItemCollection");
        List<MenuItem> menus = mic.getMenuItems();
        for(MenuItem menu:menus)
        {
        	System.out.println(menu.getName());
        }
    }
}
