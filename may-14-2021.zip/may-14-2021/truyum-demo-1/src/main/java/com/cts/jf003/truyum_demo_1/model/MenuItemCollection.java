package com.cts.jf003.truyum_demo_1.model;

import java.util.List;

public class MenuItemCollection {
	private List<MenuItem> menuItems;
	public MenuItemCollection() {}
	public MenuItemCollection(List<MenuItem> menuItems) {
		super();
		this.menuItems = menuItems;
	}
	public List<MenuItem> getMenuItems() {
		return menuItems;
	}
	public void setMenuItems(List<MenuItem> menuItems) {
		this.menuItems = menuItems;
	}
	
}
